/* countEven.h 
   Written by Ashesh Mahidadia, October 2017
*/

#include "BSTree.h"

int countEven(BSTree t);



