./q2 tests/graph2 3 3 | sort -n
