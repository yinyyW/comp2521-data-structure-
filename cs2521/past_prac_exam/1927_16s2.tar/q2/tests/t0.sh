./q2 tests/graph1 0 1 | sort -n
