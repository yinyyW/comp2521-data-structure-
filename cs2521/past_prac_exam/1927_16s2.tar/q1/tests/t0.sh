./q1 0 < tests/tree0
